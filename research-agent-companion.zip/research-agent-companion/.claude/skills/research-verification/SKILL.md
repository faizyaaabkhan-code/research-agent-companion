---
name: research-verification
description: Ensures research output distinguishes established fact from inference and states scope explicitly. Use for any task producing a written research summary or report.
---

## Procedure
1. State the interpreted scope in one sentence before writing.
2. Label each major claim implicitly by tone: established
   facts are stated plainly; inferences or uncertain claims
   are explicitly flagged as such.
3. Before finishing, re-read the draft specifically checking
   for confident-sounding claims that weren't actually verified.
