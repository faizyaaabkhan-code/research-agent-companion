# Example research note

Replace this with your own reference material. Once this
folder is connected as an MCP server, the agent can read,
search, and list files here.
