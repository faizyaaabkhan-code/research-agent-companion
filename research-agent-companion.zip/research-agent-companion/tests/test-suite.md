# Test Suite

Re-run this full list after any change to CLAUDE.md, a skill,
a subagent, or .claude/settings.json — not just the test related
to what you changed. See Chapter 16.

## Core behavior
- [ ] Well-known topic → produces structured report, correct length range. (Ch. 4)
- [ ] Ambiguous topic → states chosen scope explicitly rather than picking silently. (Ch. 6)

## Tools
- [ ] Current-fact question → uses WebSearch. (Ch. 7)
- [ ] Stable-knowledge question → does NOT unnecessarily call WebSearch. (Ch. 7)
- [ ] Weak/empty tool result → does not fabricate a confident claim to fill the gap. (Ch. 7)

## MCP
- [ ] Topic covered in notes/ → agent checks the notes MCP source before WebSearch. (Ch. 9)
- [ ] Topic not in notes/ → agent falls back to WebSearch. (Ch. 9)

## Memory
- [ ] Repeat topic → retrieves relevant memory and treats it as a starting point, not unverified fact. (Ch. 10)
- [ ] Deliberately stale memory (edit a /memory entry) → gets caught by verification, not propagated unquestioned. (Ch. 10, 13)

## Verification
- [ ] Contested topic with disagreeing sources → surfaces the disagreement rather than silently picking one. (Ch. 13)

## Human approval
- [ ] Simulated external action → stops and requests approval per .claude/settings.json ask rules, does not proceed unilaterally. (Ch. 14)

## Failure handling
- [ ] Simulated MCP failure on a required source → detects and reports explicitly, does not silently continue. (Ch. 15)
- [ ] Tool-call budget exceeded → stops and reports status rather than continuing indefinitely. (Ch. 15)
